#include "BackendAuthManager.h"
#include "BackendManager.h"
#include "BackendPalette.h"

#include <cpr/cpr.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

BackendAuthManager::BackendAuthManager(BackendManager& bm)
    : backend(bm)
{
}

AuthResult BackendAuthManager::loginUser(
    const juce::String& usernameOrEmail,
    const juce::String& password)
{
    backend.writeLog("loginUser() appelé pour: " + usernameOrEmail);

    json payload{
        { "identifier", usernameOrEmail.toStdString() },
        { "password",   password.toStdString() }
    };

    auto url = backend.getApiUrl() + "/auth/signin";

    auto response = cpr::Post(
        cpr::Url{ url.toStdString() },
        cpr::Header{ { "Content-Type", "application/json" } },
        cpr::Body{ payload.dump() }
    );

    // Erreur réseau (pas d'Internet, DNS, serveur inaccessible, etc.)
    if (response.error.code != cpr::ErrorCode::OK)
    {
        backend.writeLog(
            "CPR error: "
            + juce::String((int)response.error.code)
            + " - "
            + juce::String(response.error.message));

        return AuthResult{
            false,
            {},
            Strings::Errors::NetworkError
        };
    }

    // Erreur HTTP
    if (response.status_code != 200)
    {
        juce::String message = Strings::Errors::UnknownError;

        try
        {
            auto body = json::parse(response.text);

            if (body.contains("detail"))
                message = body["detail"].get<std::string>();
        }
        catch (...)
        {
            message = Strings::Errors::UnknownError;
        }

        return AuthResult{ false, {}, message };
    }

    // Succès
    auto body = json::parse(response.text);

    UserSession session;
    session.isGuest     = false;
    session.userId      = body.value("user_id", 0);
    session.accessToken = body.value("token", "");
    session.pseudo      = body.value("username", "");
    session.email       = body.value("email", "");

    // La palette vient uniquement de la réponse du backend
    BackendPalette::readFromJson(body, session.paletteColours, session.paletteSlot);

    session.expiresAt = juce::Time::getCurrentTime()
                        + juce::RelativeTime::hours(1);

    saveSession(session);

    syncProfileParamsInBackground(session);

    return AuthResult{ true, session, {} };
}

AuthResult BackendAuthManager::signupUser(
    const juce::String& username,
    const juce::String& firstname,
    const juce::String& lastname,
    const juce::String& email,
    const juce::String& password)
{
    backend.writeLog("signupUser() appelé pour: " + username);

    json payload{
        { "username",   username.toStdString() },
        { "first_name", firstname.toStdString() },
        { "last_name",  lastname.toStdString() },
        { "email",      email.toStdString() },
        { "password",   password.toStdString() }
    };

    auto url = backend.getApiUrl() + "/auth/signup";

    auto response = cpr::Post(
        cpr::Url{ url.toStdString() },
        cpr::Header{ { "Content-Type", "application/json" } },
        cpr::Body{ payload.dump() }
    );

    if (response.error.code != cpr::ErrorCode::OK)
    {
        backend.writeLog(
            "CPR error: "
            + juce::String((int)response.error.code)
            + " - "
            + juce::String(response.error.message));

        return AuthResult{
            false,
            {},
            Strings::Errors::NetworkError
        };
    }

    backend.writeLog("Status signup: " + juce::String(response.status_code));
    backend.writeLog("Réponse brute signup: " + juce::String(response.text.c_str()));

    if (response.status_code != 200)
    {
        juce::String message = Strings::Errors::UnknownError;

        try
        {
            auto body = json::parse(response.text);

            if (body.contains("detail"))
            {
                auto detail = body["detail"];

                if (detail.is_array() && !detail.empty())
                {
                    auto error = detail[0];

                    std::string type = error.value("type", "");
                    std::string field = "";

                    if (error.contains("loc") && error["loc"].is_array())
                    {
                        for (auto& item : error["loc"])
                        {
                            if (item.is_string() && item != "body")
                            {
                                field = item.get<std::string>();
                            }
                        }
                    }

                    // Invalid email
                    if (field == "email")
                    {
                        message = "Please enter a valid email address.";
                    }
                    // Password too short
                    else if (field == "password" &&
                            type == "string_too_short")
                    {
                        int minLength = 0;

                        if (error.contains("ctx") &&
                            error["ctx"].contains("min_length"))
                        {
                            minLength = error["ctx"]["min_length"];
                        }

                        message = "Password must contain at least "
                                + juce::String(minLength)
                                + " characters.";
                    }
                    // Missing field
                    else if (type == "missing")
                    {
                        message = "A required field is missing.";
                    }
                    else
                    {
                        message = "Invalid input.";
                    }
                }
                else if (detail.is_string())
                {
                    message = detail.get<std::string>();
                }
            }
        }
        catch (...)
        {
            message = Strings::Errors::UnknownError;
        }

        return AuthResult{ false, {}, message };
    }

    auto body = json::parse(response.text);

    UserSession session;
    session.isGuest     = false;
    session.userId      = body.value("user_id", 0);
    session.accessToken = body.value("token", "");
    session.pseudo      = body.value("username", "");
    session.email       = body.value("email", "");

    // La palette vient uniquement de la réponse du backend
    BackendPalette::readFromJson(body, session.paletteColours, session.paletteSlot);

    session.expiresAt = juce::Time::getCurrentTime()
                        + juce::RelativeTime::hours(1);

    saveSession(session);

    syncProfileParamsInBackground(session);

    return AuthResult{ true, session, {} };
}

void BackendAuthManager::saveSession(const UserSession& session)
{
    backend.writeLog("saveSession()");
    saveSessionToFile(backend.getSessionFile(), session);
    backend.writeLog("Session écrite.");
}

void BackendAuthManager::saveSessionToFile(const juce::File& sessionFile, const UserSession& session)
{
    json colours = json::array();
    for (const auto& c : session.paletteColours)
        colours.push_back(c.toStdString());

    json j{
        { "isGuest",        session.isGuest },
        { "userId",         session.userId },
        { "pseudo",         session.pseudo.toStdString() },
        { "email",          session.email.toStdString() },
        { "accessToken",    session.accessToken.toStdString() },
        { "expiresAt",      (long long) session.expiresAt.toMilliseconds() },
        { "paletteColours", colours },
        { "paletteSlot",    session.paletteSlot }
    };

    sessionFile.replaceWithText(j.dump(4));
}

std::optional<UserSession> BackendAuthManager::loadSession()
{
    backend.writeLog("loadSession()");

    auto sessionFile = backend.getSessionFile();

    backend.writeLog("Session file: " + sessionFile.loadFileAsString());

    if (!sessionFile.existsAsFile()) {
        backend.writeLog("no session found");
        return std::nullopt;
    }

    return loadSessionFromFile(sessionFile);
}

std::optional<UserSession> BackendAuthManager::loadSessionFromFile(const juce::File& sessionFile)
{
    if (!sessionFile.existsAsFile())
        return std::nullopt;

    auto content = sessionFile.loadFileAsString();
    auto j = json::parse(content.toStdString());

    UserSession session;
    session.userId      = j.value("userId", 0);
    session.pseudo      = j.value("pseudo", "");
    session.email       = j.value("email", "");
    session.accessToken = j.value("accessToken", "");
    session.isGuest     = j.value("isGuest", false);

    session.paletteSlot = j.value("paletteSlot", 0);

    if (j.contains("paletteColours") && j["paletteColours"].is_array())
        for (const auto& c : j["paletteColours"])
            if (c.is_string())
                session.paletteColours.add(c.get<std::string>());

    // Ancien fichier de session ou données invalides : on repart de zéro
    if (session.paletteColours.size() != 3)
        session.paletteColours.clear();

    auto expiresMs = j.value("expiresAt", static_cast<int64_t>(0));
    session.expiresAt = juce::Time(expiresMs);

    if (session.accessToken.isEmpty() && !session.isGuest)
        return std::nullopt;

    return session;
}

void BackendAuthManager::clearSession()
{
    backend.writeLog("clearSession()");

    auto sessionFile = backend.getSessionFile();
    if (sessionFile.existsAsFile())
        sessionFile.deleteFile();
}

void BackendAuthManager::syncProfileParamsInBackground(const UserSession& session)
{
    // Captured by value (not `this`/`backend`): the owning BackendManager is
    // destroyed every time the plugin editor window closes, but this thread
    // is detached and may still be in flight when that happens.
    const auto apiUrl      = backend.getApiUrl();
    const auto sessionFile = backend.getSessionFile();
    const auto logFile     = backend.getLogFile();

    std::thread([apiUrl, sessionFile, logFile, session]()
    {
        auto url = apiUrl + "/profile/me";

        auto response = cpr::Get(
            cpr::Url{ url.toStdString() },
            cpr::Header{
                { "Authorization", "Bearer " + session.accessToken.toStdString() }
            }
        );

        if (response.status_code != 200)
            return;

        try
        {
            auto body = json::parse(response.text);

            UserSession updated = session;
            updated.userId   = body.value("user_id", session.userId);
            updated.pseudo   = body.value("username", session.pseudo.toStdString()).c_str();
            updated.email    = body.value("email", session.email.toStdString()).c_str();

            BackendPalette::readFromJson(body, updated.paletteColours, updated.paletteSlot);

            saveSessionToFile(sessionFile, updated);

            if (logFile != juce::File())
                logFile.appendText("[Backend] Session sync depuis backend.\n");
        }
        catch (...) {}
    }).detach();
}

std::optional<UserSession> BackendAuthManager::syncProfileParams(const UserSession& session)
{
    auto updated = syncProfileParamsFromServer(backend.getApiUrl(), backend.getSessionFile(), session);
    backend.writeLog(updated ? "Session synced (blocking) from backend."
                              : "Blocking sync failed.");
    return updated;
}

std::optional<UserSession> BackendAuthManager::syncProfileParamsFromServer(const juce::String& apiUrl,
                                                                            const juce::File& sessionFile,
                                                                            const UserSession& session)
{
    auto url = apiUrl + "/profile/me";

    auto response = cpr::Get(
        cpr::Url{ url.toStdString() },
        cpr::Header{
            { "Authorization", "Bearer " + session.accessToken.toStdString() }
        }
    );

    if (response.status_code != 200)
        return std::nullopt;

    try
    {
        auto body = json::parse(response.text);

        UserSession updated = session;
        updated.userId   = body.value("user_id", session.userId);
        updated.pseudo   = body.value("username", session.pseudo.toStdString()).c_str();
        updated.email    = body.value("email", session.email.toStdString()).c_str();

        BackendPalette::readFromJson(body, updated.paletteColours, updated.paletteSlot);

        saveSessionToFile(sessionFile, updated);

        return updated;
    }
    catch (...)
    {
        return std::nullopt;
    }
}