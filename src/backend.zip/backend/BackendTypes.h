/**
 * @file BackendTypes.h
 * @brief Defines backend-related data structures.
 *
 * This file contains all shared backend structures used
 * across the application.
 *
 * Included structures:
 * - UserSession
 * - AuthResult
 * - UserProfile
 * - ProfileResult
 * - AiResult
 */
#pragma once

#include <nlohmann/json.hpp>
#include "../config/String.h"
#include "../config/AppConfig.h"
#include <juce_core/juce_core.h>

struct UserSession
{
    bool isGuest = true;

    int userId = 0;

    juce::String pseudo;
    juce::String email;
    juce::String accessToken;
    juce::Time   expiresAt;

    juce::StringArray paletteColours;   // 3 hex "#RRGGBB", vide = pas encore reçu du backend
    int paletteSlot = 0;                // 0..2 côté front (backend : last_color_id 1..3)
};

struct AuthResult
{
    bool success = false;
    UserSession session;
    juce::String errorMessage;
};

struct UserProfile
{
    int         id = 0;
    std::string username;
    std::string email;
    std::string firstName;
    std::string lastName;
    std::string createdAt;
    std::string role;
    bool        isActive = true;

    juce::StringArray paletteColours;   // 3 hex "#RRGGBB"
    int paletteSlot = 0;                // 0..2
};

struct ProfileResult
{
    bool success = false;
    std::string errorMessage;
    UserProfile profile;

    static ProfileResult ok(const UserProfile& profile)
    {
        return { true, "", profile };
    }

    static ProfileResult error(const std::string& message)
    {
        return { false, message, {} };
    }
};

struct AiResult
{
    enum class Error
    {
        None,
        EmptyPrompt,
        NoSession,
        SessionExpired,
        Network,
        HttpError,
        EmptyResponse,
        Unknown
    };

    bool success = false;
    juce::String json;
    juce::String errorMessage;
    Error error = Error::Unknown;

    static inline AiResult ok(const juce::String& json)
    {
        return AiResult{
            true,
            json,
            {},
            Error::None
        };
    }

    static inline AiResult failure(Error e, const juce::String& message)
    {
        return AiResult{
            false,
            {},
            message,
            e
        };
    }
};